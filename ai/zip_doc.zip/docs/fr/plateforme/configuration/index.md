# Configuration
Cette  rubrique permet de configurer la plateforme. Dans cette rubrique l'utilisateur pourra accéder à de nombreuse rubrique à savoir

### Sous rubriques de la rubrique **Configuration**

![configuration](../navigation/images/sous_menu_configuration.png)

* [Informations :](information/) Personnaliser le module de passation PROOVme.

* [Licence :](licence/) Information sur votre licence.

* [Sécurité :](sécurité/) Définition d'un niveau de sécurité pour les candidats.

* [Promotions :](promotions/) Gestion des promotions.

* [Sessions :](session/) Gestion des sessions.

* [Catégories :](catégories/) Gestion des catégories personnalisées.


