La rubrique Utilisateurs regroupe l’ensemble des fonctionnalités permettant d’administrer les accès à la plateforme. Elle se compose de trois sous-rubriques complémentaires :

### Sous rubriques de la rubrique **Utilisateurs**

Ensemble, ces trois sous-rubriques offrent une gestion complète des accès : depuis la création d’un compte, jusqu’à l’attribution de droits précis et le rattachement à une équipe.

![Utilisateurs](./images/users.png)

* [Utilisateurs :](utilisateurs/) permet de créer, consulter et gérer les comptes des personnes ayant accès à la plateforme. On y retrouve leurs informations principales (identité, e-mail, identifiant, état du compte)

* [Rôles :](roles/) permet de définir et d’attribuer des profils de droits (administrateur, superviseur, correcteur, candidat, etc.) afin de contrôler les actions que chaque utilisateur peut effectuer

* [Équipe :](equipes/) permet de regrouper plusieurs utilisateurs dans des ensembles logiques (par exemple par service, établissement, promotion ou projet) pour faciliter la gestion collective et l’attribution des rôles

