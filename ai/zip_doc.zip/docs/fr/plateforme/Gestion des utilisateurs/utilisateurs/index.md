La sous-rubrique Utilisateurs permet de gérer l’ensemble des comptes créés sur la plateforme. Elle offre une vision complète des personnes enregistrées et permet d’assurer le suivi de leurs accès.

## Consultation de la liste des utilisateurs

![Utilisateurs](./images/users.png)

Chaque utilisateur est affiché avec ses informations principales :  

* Nom et prénom
* Adresse e-mail
* Identifiant de connexion

Des indicateurs visuels permettent de suivre l’état du compte :  

![Utilisateurs](./images/etats_users_users.png)

* État de connexion :
    * Rouge : utilisateur jamais connecté
    * Gris : utilisateur déconnecté
    * Vert : utilisateur actuellement connecté 


* État du mot de passe :  
    * 🔒 Vert : mot de passe initialisé  

    * 🔒 Gris : mot de passe non initialisé  

    * 🔒 Bleu : attente d’initialisation du mot de passe  


## Actions disponibles

Depuis cet écran, plusieurs actions sont possibles :  

![Utilisateurs](./images/act_users_users.png)

* Modifier les informations d’un utilisateur (icône crayon sur chaque ligne de la liste)
* Ajouter un nouvel utilisateur (bouton **+ AJOUTER UN UTILISATEUR**)
* Demander une réinitialisation de mot de passe (icône enveloppe)
* Supprimer un ou plusieurs utilisateurs (icône corbeille, avec demande de confirmation)

## Ajouter un nouvel utilisateur

La fonction **Ajouter un utilisateur** permet de créer un nouveau compte et de l’associer aux informations et catégories nécessaires pour son utilisation de la plateforme. En cliquant sur le bouton **+ AJOUTER UN UTILISATEUR**, une fenêtre de saisie s’ouvre.

![Utilisateurs](./images/add_users_users.png)

### Informations à renseigner

L’administrateur doit compléter les champs suivants :  

* Prénom et Nom de l’utilisateur
* Identifiant de connexion (servira lors de l’accès à la plateforme)
* Numéro de téléphone (sélection du code pays et saisie du numéro)
* Adresse e-mail de contact

### Catégories associées

Il est possible de rattacher l’utilisateur à différentes catégories afin de préciser son profil :  

* Matières : exemple Anglais, Cinéma, Français, Histoire de France
* Niveaux : permet d’associer l’utilisateur à un niveau d’enseignement ou de compétence

### Actions disponibles

* Bouton **Créer** : enregistre la saisie et ajoute immédiatement le nouvel utilisateur à la liste
* Bouton **Annuler** : ferme la fenêtre sans créer de compte


## Modifier les informations d’un utilisateur

La fonction **Modifier** permet d’actualiser les informations d’un utilisateur déjà créé sur la plateforme. En cliquant sur l’icône crayon depuis la liste des utilisateurs, une fenêtre de modification s’ouvre.

![Utilisateurs](./images/mod_users_users.png)

### Informations modifiables

L’administrateur peut mettre à jour :  

* Nom et prénom de l’utilisateur
* Identifiant de connexion (utilisé pour l’accès à la plateforme)
* Numéro de téléphone (avec sélection du code pays)
* Adresse e-mail de contact

### Catégories associées

En complément des informations personnelles, il est possible d’associer l’utilisateur à des catégories :  

* Matières (ex. : Anglais, Cinéma, Français, Histoire de France)
* Niveaux (permet de rattacher l’utilisateur à un niveau d’enseignement ou de compétence)

### Actions disponibles

* Bouton **Modifier** : enregistre et applique immédiatement les changements saisis sur le compte utilisateur. L’utilisateur sera ensuite mis à jour dans la liste
* Bouton **Annuler** : ferme la fenêtre de modification sans sauvegarder les informations modifiées. Aucune donnée n’est impactée


## Demander une réinitialisation de mot de passe

La fonction **Demander une réinitialisation de mot de passe** permet à l’administrateur d’envoyer automatiquement un e-mail de récupération aux utilisateurs sélectionnés. Cette action est accessible depuis l’icône enveloppe située en haut de la liste des utilisateurs.

![Utilisateurs](./images/sendmail_users_users.png)

Fonctionnement :  

* Lorsqu’elle est activée, une fenêtre de confirmation s’affiche pour informer l’administrateur de l’opération.
* Le mot de passe de l’utilisateur est réinitialisé automatiquement et remplacé par un mot de passe temporaire.
* L’utilisateur reçoit par e-mail ses informations de connexion, avec l’obligation de changer son mot de passe dès la prochaine connexion pour des raisons de sécurité.

![Utilisateurs](./images/mailpassword_users_users.png)


Actions disponibles :  

* Bouton **Confirmer** : lance l’opération et envoie immédiatement l’e-mail de réinitialisation.
* Bouton **Annuler** : ferme la fenêtre sans effectuer de modification.

## Supprimer un ou plusieurs utilisateurs

La fonction **Supprimer** permet de retirer définitivement un ou plusieurs comptes utilisateurs de la plateforme. Cette action est accessible via l’icône corbeille située en haut de la liste des utilisateurs.

Fonctionnement :  

* L’administrateur doit d’abord sélectionner un ou plusieurs utilisateurs dans la liste
* En cliquant sur l’icône **corbeille**, une fenêtre de confirmation s’ouvre afin d’éviter toute suppression accidentelle

![Utilisateurs](./images/supp_users_users.png)

* Une fois validée, l’opération entraîne la suppression définitive du ou des comptes sélectionnés, ainsi que de leurs informations associées

Actions disponibles :   

* Bouton **CONFIRMER** : valide l’opération et supprime immédiatement les utilisateurs sélectionnés.
* Bouton **ANNULER** : ferme la fenêtre de confirmation et annule la suppression.

⚠️ **Attention** : la suppression d’un compte est irréversible. Si l’utilisateur doit de nouveau accéder à la plateforme, un nouveau compte devra être recréé.


## Filtrage et recherche

![Utilisateurs](./images/filtre_users_users.png)

* Une barre de recherche permet de retrouver rapidement un utilisateur
* Des filtres sur les colonnes facilitent le tri et la sélection des utilisateurs en fonction de leurs caractéristiques (nom, état, rôle, etc.)
