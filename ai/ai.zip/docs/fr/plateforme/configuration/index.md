# Configuration
Cette  rubrique permet de configurer la plateforme. Dans cette rubrique l'utilisateur pourra accéder à de nombreuse rubrique à savoir

### Sous rubriques de la rubrique **Configuration**

![configuration](../navigation/images/sous_menu_configuration.png)

* [Informations :](information/) Permet d’activer la vérification d’identité des candidats.

* [Licence :](licence/) Permet d’activer la vérification d’identité des candidats.

* [Sécurité :](sécurité/) Permet d’activer la vérification d’identité des candidats.

* [Promotions :](promotions/) Permet de gérer les promotions utilisées sur la plateforme.

* [Sessions :](session/) Permet de gérer les différentes sessions d’épreuves.

* [Catégories :](catégories/) Permet de créer et gérer des catégories personnalisées.


