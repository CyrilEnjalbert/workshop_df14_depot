# Intro

!!! warning "Accès par rôle"

    Seuls les **reponsables** ont accès à cette fonctionnalité.
    Les gestionnaires sont limités à leur propre catégorie et n'ont pas accès à toutes les fonctionnalités indiquées.

## Partie 1


## Partie 2


## Partie 3