# Documentation PROOVme Gestion


![Logo](assets/logo_proovme.png)

## Présentation de PROOVme

**PROOVme** est une solution qui permet de gérer des épreuves, de créer des sujets et d’organiser des passations, en présentiel ou à distance.

Les **gestionnaires** et **pédagogues** utilisent la gestion PROOVme pour administrer l’ensemble du dispositif. Celle-ci permet de gérer les utilisateurs, les candidats, les sujets, les épreuves, ainsi que la correction.

Les **candidats** utilisent une application installée sur leur ordinateur pour réaliser leur passation et consulter leurs résultats.


### Guide d'utilisation de la gestion

* [Connexion :](gestion/connexion/) Connexion à l'application
* [Mon compte :](gestion/mon-compte/) Personaliser son compte
* [Navigation :](gestion/navigation/) Comment naviguer dans l'application
* [Configuration :](gestion/configuration/) Configuration de l'application
* [Gestion des utilisateurs :](gestion/gestion-des-utilisateurs/) Création et gestion des utilisateurs
* [Gestion des candidats :](gestion/gestion-des-candidats/) Création et gestion des candidats
* [Sujets :](gestion/gestion-des-sujets/) Réalisation et gestion des sujets
* [Epreuves :](gestion/gestion-des-epreuves/) Création et gestion des épreuves

## Démarrage rapide

* [Demarrer avec PROOVme Gestion](quickstart.md)

## Foire aux questions

* [FAQ](faq/)