La rubrique **Listes** permet de créer et de gérer des regroupements de candidats selon des critères définis (promotion, année d’étude, spécialité, session, etc.). Ces listes facilitent l’organisation, la convocation et le suivi des candidats.

![listes](images/listes_candidats.png)

## Accéder aux listes :  

* Depuis le menu Gestion des candidats, sélectionnez **Listes**
* Le panneau de gauche affiche l’ensemble des listes disponibles

## Ajouter une liste

La fonction **Ajouter une liste** permet de créer un regroupement de candidats (ex. : L1 – Informatique, Session rattrapage UE 2.3).
On y accède depuis Candidats > Listes puis + Nouvelle liste.

Étapes  

![listes](images/creat_listes_candidats.png)

* Cliquer sur **+ Nouvelle liste**
* Renseigner Intitulé de la liste (obligatoire)
* Choisir la visibilité :  
	* Liste globale : visible et utilisable par l’ensemble des utilisateurs autorisés de l’établissement
	* Liste privée : visible uniquement par son créateur
* Cliquer sur Créer.

Le bouton **Créer** reste inactif tant que l’intitulé n’est pas saisi.

## Renommer une liste de candidats

Il est possible de modifier l’intitulé d’une liste déjà créée.

Étapes à suivre  

* Rendez-vous dans Candidats > Listes
* Repérez la liste que vous souhaitez renommer

* Cliquez sur le menu ⋮ à droite du nom de la liste

![listes](images/menu_listes_candidats.png)

* Sélectionnez Renommer
* Le nom de la liste devient éditable : saisissez le nouvel intitulé

![listes](images/renommer_listes_candidats.png)

* Validez avec la touche Entrée
* Vous pouvez également annuler en appuyant sur Échap ou en cliquant en dehors du champ

Points à savoir
* L’intitulé d’une liste est obligatoire
* Deux listes portant le même nom ne peuvent pas coexister dans la même session
* Une fois validé, le nouveau nom apparaît immédiatement dans la liste

## Dupliquer une liste de candidats

La duplication permet de créer rapidement une nouvelle liste à partir d’une liste existante. Tous les candidats rattachés à la liste d’origine sont copiés dans la nouvelle liste.

Étapes à suivre  

* Rendez-vous dans Candidats > Listes
* Repérez la liste que vous souhaitez dupliquer

* Cliquez sur le menu ⋮ à droite du nom de la liste

![listes](images/menu_listes_candidats.png)

* Sélectionnez Dupliquer
* Une fenêtre s’ouvre avec l’intitulé de la nouvelle liste, reprenant le nom d’origine suivi d’un numéro (exemple : L1 – Informatique, session de rattrapage UE 2.3 (1))

![listes](images/dupliquer_listes_candidats.png)

* Modifiez le nom si nécessaire
* Cliquez sur Créer pour valider

Points à savoir  
* Tous les candidats présents dans la liste d’origine sont copiés automatiquement dans la nouvelle liste
* La nouvelle liste est indépendante de la première : toute modification apportée n’affecte pas la liste d’origine
* Vous pouvez renommer la liste immédiatement lors de la création
* La duplication respecte la visibilité de la liste initiale (globale ou privée)

## Supprimer une liste de candidats

Vous pouvez supprimer définitivement une liste de candidats qui n’est plus utile.

Étapes à suivre 

* Rendez-vous dans Candidats > Listes
* Repérez la liste que vous souhaitez supprimer
* Cliquez sur le menu ⋮ à droite du nom de la liste

![listes](images/menu_listes_candidats.png)

* Sélectionnez **Supprimer**
* Une fenêtre de confirmation s’affiche : **« Êtes-vous sûr(e) de vouloir supprimer cette liste de candidats ? »**

![listes](images/supp_listes_candidats.png)

* Cliquez sur **Oui** pour confirmer ou sur **Non** pour annuler.

Points à savoir 

* La suppression est définitive : la liste et ses rattachements disparaissent
* Les candidats ne sont pas supprimés de la base, seul le regroupement (la liste) est supprimé
* Vous ne pourrez plus restaurer la liste une fois la suppression validée

### Cas particuliers avec les épreuves

* Si la liste supprimée est utilisée dans une épreuve non programmée :  
	* Une indication s’affiche dans la gestion de l’épreuve
	* Vous devrez alors soit assigner une autre liste, soit retirer la liste supprimée si d’autres listes sont déjà présentes 

* Si la liste supprimée est utilisée dans une épreuve programmée ou déjà réalisée :
	* Les candidats de cette liste restent assignés à l’épreuve
	* Aucune modification ni suppression n’est appliquée aux candidats de cette épreuve

## Contenu d’une liste :

Chaque liste regroupe les candidats associés à un même critère.  

Par exemple : Étudiants de première année – Cinéma.

![listes](images/detail_listes_candidats.png)

En sélectionnant une liste, la partie droite de l’écran affiche le détail des candidats qui y sont associés :  

* Nom et Prénom
* E-mail
* Identifiant
* État du mot de passe (icônes cadenas)
* Promotion
* Tags

## Actions disponibles dans une liste :  

Lorsque vous ouvrez une liste, plusieurs actions de gestion et d’organisation sont possibles :  

* Ajouter des candidats dans une liste 
* Retirer un candidat dans une liste  
* Rechercher et filtrer 

### Ajouter des candidats dans une liste 

La fonction **Ajouter des candidats** dans une liste permet de sélectionner un ou plusieurs candidats déjà créés dans la gestion afin de les rattacher à une liste spécifique (ex. : Étudiants de première année – Cinéma).

Étapes :  

* Depuis la rubrique Listes, ouvrez la liste souhaitée
* Cliquez sur **+ AJOUTER DES CANDIDATS** en haut à droite

![listes](images/add_cand_listes_candidats.png)

* Une fenêtre s’ouvre affichant l’ensemble des candidats disponibles sur la gestion, qu’ils soient déjà associés à une autre liste ou non
* Utilisez les outils de recherche et de filtrage pour affiner l’affichage :
	* Recherche 🔍 : par nom, prénom, e-mail ou identifiant
	* Filtres : possibilité de filtrer par promotion, session, tags ou appartenance à une autre liste
	* Compteurs (en haut à gauche) :
		* Total : nombre total de candidats enregistrés dans la gestion
		* Filtrés : nombre de candidats correspondant aux critères de recherche ou filtres appliqués
		* Sélectionnés : nombre de candidats actuellement cochés pour être ajoutés à la liste
* Sélectionnez les candidats à ajouter en cochant les cases correspondantes
* Cliquez sur **AJOUTER** pour valider l’opération
* Les candidats sélectionnés apparaissent immédiatement dans la liste

Remarques spécifiques :  

* Les candidats peuvent être ajoutés à une liste qu’ils soient déjà associés à d’autres listes ou non
* Un même candidat peut appartenir à plusieurs listes simultanément
* L’ajout à une liste n’altère pas les informations personnelles ou académiques du candidat (promotion, identifiant, état du mot de passe, etc.)
* La recherche multi-critères (par colonnes, filtres et appartenance à d’autres listes) facilite la gestion de grands volumes de candidats

### Retirer un candidat d’une liste 

* Dans le détail d’une liste, repérez le candidat à retirer
* Cliquez sur l’icône ![listes](images/retirer_listes_candidats.png) (silhouette barrée en rose) située à droite de sa ligne
* Une fenêtre de confirmation s’affiche avec le message :  

    ![listes](images/conf_retirer_listes_candidats.png) 

	* Êtes-vous sûr(e) de vouloir retirer le/la candidat(e) [Nom Prénom] de la liste ? »
    * Cliquez sur **CONFIRMER** pour valider ou sur **ANNULER** pour interrompre l’action

* Le candidat est immédiatement retiré de la liste sélectionnée.

Remarques spécifiques :  

* Le retrait d’un candidat d’une liste ne supprime pas son compte de la gestion
* Le candidat reste accessible dans la base globale et peut être rattaché à d’autres listes
* Cette action est réversible : vous pouvez réintégrer le candidat ultérieurement en utilisant **+ AJOUTER DES CANDIDATS**

### Rechercher et filtrer

![listes](./images/filtres_listes_candidats.png)

* Recherche 🔍 : permet de retrouver rapidement un candidat en saisissant son nom, prénom, identifiant ou e-mail
* Compteurs (affichés sous la barre de recherche) :  

	* Total : nombre total de candidats créés sur la gestion
	* Filtrés : nombre de candidats correspondant aux filtres appliqués
	* Sélectionnés : nombre de candidats actuellement sélectionnés dans la liste, sur lesquels une action groupée peut être appliquée. 

* Filtres par colonne : chaque colonne du tableau dispose de son propre filtre permettant de restreindre l’affichage selon une valeur précise (ex. : afficher uniquement une promotion, un identifiant, un tag ou un état de mot de passe)