La rubrique Sécurité des postes permet de gérer les ordinateurs utilisés par les candidats lors de leurs épreuves.

![Listes](images/rubrique_security_candidats.png)

Lorsqu’un candidat installe l’application PROOVme sur son ordinateur, un jumelage est effectué : cela signifie que l’établissement connaît la machine associée au candidat.
Un candidat ne pourra donc utiliser que l’ordinateur validé par l’établissement.

## Informations disponibles

Dans cette rubrique, plusieurs indicateurs vous permettent de suivre la situation de chaque candidat :  

* Identité du candidat : identifiant, nom et prénom
* RGPD : statut de validation du consentement RGPD
* Validation par mail (si activée) : confirme que le candidat est bien le propriétaire de l’adresse mail associée
* Captation du visage (si activée) : permet de comparer la photo du candidat lors d’un contrôle d’identité en épreuve
* État de l’ordinateur : indique le statut du jumelage
* Compatibilité de l’ordinateur : vérifie si l’appareil est capable de faire fonctionner l’application PROOVme

## États de l’ordinateur

Un ordinateur peut avoir plusieurs états :  

* Non autorisé : le responsable n’a pas encore donné d’autorisation
* Autorisé : la machine est autorisée mais le jumelage n’est pas encore finalisé
* Finalisé : l’ordinateur est autorisé et le jumelage a été effectué
* Annulé : le candidat n’a plus le droit d’utiliser cette machine

## Compatibilité de l’ordinateur

Trois indicateurs permettent de suivre la compatibilité technique de la machine avec l’application PROOVme :  

* Test non réalisé : le candidat n’a pas encore installé ou ouvert l’application
* Ordinateur compatible : l’application fonctionne correctement sur la machine
* Ordinateur non compatible : la machine ne peut pas être utilisée pour passer une épreuve

## Actions possibles

Depuis cette rubrique, vous pouvez :  

![securite-des-postes](images/menu_security_candidats.png)

* Autoriser l’association : permettre au candidat de jumeler sa machine
* Changer d’ordinateur : remplacer l’ordinateur associé par un autre appareil
* Annuler l’autorisation : retirer l’autorisation donnée à une machine

## Filtrer les postes des candidats

La rubrique Sécurité des postes propose des outils de recherche et de filtrage afin de retrouver facilement un candidat ou un groupe de candidats.

![securite-des-postes](images/filtre_security_candidats.png)

### Barre de recherche

En haut de la page, une barre de recherche permet de saisir directement un identifiant, un nom ou un prénom afin de retrouver rapidement un candidat dans la liste.
Sous la barre de recherche, trois informations sont affichées :  

* Total : nombre total de candidats
* Filtrés : nombre de candidats correspondant à vos critères de recherche
* Sélectionnés : nombre de candidats actuellement sélectionnés dans le tableau

### Filtres par colonne

Chaque colonne du tableau dispose également d’un filtre dédié.  

Vous pouvez ainsi :  

* filtrer par statut RGPD
* filtrer par validation mail
* filtrer par statut de l’identité (captation du visage)
* filtrer par état de l’ordinateur (Non autorisé, Autorisé, Finalisé, Annulé)
* filtrer par compatibilité de l’ordinateur (Test non réalisé, Compatible, Non compatible)

### Résultat

Les candidats correspondant aux filtres s’affichent immédiatement dans la liste.
Le compteur Filtrés se met à jour automatiquement pour indiquer le nombre de résultats trouvés.