La rubrique Candidats permet de gérer l’ensemble des personnes inscrites à vos épreuves. Elle centralise leurs informations personnelles, leurs identifiants de connexion ainsi que leur rattachement aux promotions ou groupes définis par l’établissement.

![Candidats](./images/candidats.png)

Informations disponibles dans la liste des candidats :  

* Nom et Prénom
* E-mail
* Identifiant (utilisé pour la connexion)
* Mot de passe : affiché sous forme de pictogrammes indiquant l’état du compte :  

    * 🔒 Cadenas gris : le responsable n’a pas encore envoyé le mail d’initialisation du mot de passe
    * 🔒⌚ Cadenas bleu avec montre : le mail d’initialisation a été envoyé, mais le candidat n’a pas encore défini son mot de passe
    * ✅ Cadenas vert : le candidat a correctement initialisé son mot de passe et peut se connecter 

* Promotion (ex. : Promotion 2025 – Ingénieurs Agronomie)
* Tags (mots-clés ou regroupements spécifiques définis par l’administrateur)

Actions disponibles :  

![Candidats](./images/com_candidats.png)

* Ajouter un candidat ➕ : permet de créer un nouveau compte candidat avec ses informations personnelles
* Modifier ✏️ : mettre à jour les informations d’un candidat existant
* Supprimer 🗑️ : retirer définitivement un candidat de la base
* Assigner ou modifier une promotion 🎓 : sélectionnez directement la promotion d’un candidat depuis la liste via le menu déroulant de la colonne Promotion
* Actions groupées (via la sélection de plusieurs candidats) :  

    * Import des données 📄
    * Envoi d’e-mails ✉️
    * Suppression groupée 🗑️

Barre d’outils :  

![Candidats](./images/filtre.png)

* Recherche 🔍 : permet de retrouver rapidement un candidat en saisissant son nom, prénom, identifiant ou e-mail
* Compteurs (affichés sous la barre de recherche) :  

    * Total : nombre total de candidats créés sur la gestion
    * Filtrés : nombre de candidats correspondant aux filtres appliqués
    * Sélectionnés : nombre de candidats actuellement sélectionnés dans la liste, sur lesquels une action groupée peut être appliquée. 

* Filtres par colonne : chaque colonne du tableau dispose de son propre filtre permettant de restreindre l’affichage selon une valeur précise (ex. : afficher uniquement une promotion, un identifiant, un tag ou un état de mot de passe)

Remarques :  

* Cette rubrique constitue le point d’entrée pour toutes les opérations liées aux candidats, avant d’accéder aux sous-rubriques :  

    * Candidats (sous-rubrique par défaut)
    * Listes
    * Sécurité des postes

## Ajouter un candidat

La fonction **Ajouter un candidat** permet de créer un nouveau compte candidat sur la gestion afin qu’il puisse être rattaché à une promotion et participer aux épreuves.

![Candidats](./images/add_candidats.png)

Étapes :  

* Dans la rubrique Candidats, cliquez sur le bouton **+ AJOUTER UN CANDIDAT** situé en haut à droite de la liste
* Une fenêtre s’ouvre pour saisir les informations du nouveau candidat :  

    * Nom et Prénom
    * Identifiant (utilisé pour la connexion)
    * Date de naissance
    * E-mail
    * Numéro de téléphone (avec choix de l’indicatif pays)
    * Promotion (sélection via un menu déroulant)
    * Tags (optionnels, pour associer des regroupements spécifiques)  

* Cliquez sur **AJOUTER** pour valider la création.
* Le nouveau candidat apparaît immédiatement dans la liste

Remarques :  

* Les champs Nom, Prénom, Identifiant et E-mail sont obligatoires
* L’Identifiant doit être unique et ne pas être attribué à un autre candidat
* Après la création, l’utilisateur doit sélectionner un ou plusieurs candidats dans la liste, puis cliquer sur le bouton ✉️ (enveloppe) en haut à gauche pour leur envoyer le mail d’invitation à initialiser leur mot de passe
* Une fois le mot de passe initialisé, le candidat pourra se connecter et accéder à la gestion
* Vous pouvez associer le candidat à une promotion dès sa création ou la modifier ultérieurement

## Modification des informations d’un candidat

La fonction **Modifier un candidat** permet de mettre à jour les informations personnelles et académiques d’un candidat existant.

![Candidats](./images/mod_candidat.png)

Étapes :  

* Dans la liste des candidats, cliquez sur l’icône ✏️ (stylo) située à droite du candidat à modifier
* Une fenêtre s’ouvre avec les informations actuelles du candidat
* Mettez à jour les champs nécessaires :  

    * Nom et Prénom
    * Identifiant (utilisé pour la connexion)
    * Date de naissance
    * E-mail
    * Numéro de téléphone (avec choix de l’indicatif pays)
    * Promotion (sélection directe via un menu déroulant)
    * Tags (pour ajouter des regroupements spécifiques)

* Cliquez sur **MODIFIER** pour enregistrer les changements  

Les nouvelles informations sont immédiatement prises en compte dans la liste des candidats.

Remarques :  

* Les champs obligatoires sont signalés (Nom, Prénom, Identifiant, E-mail)
* L’Identifiant doit être unique et ne peut pas être attribué à deux candidats différents
* La modification n’entraîne pas la suppression des données déjà associées au candidat (résultats, historique, etc.)
* Les changements de Promotion se répercutent automatiquement sur les listes et regroupements liés

## Supprimer un candidat

La fonction **Supprimer un candidat** permet de retirer définitivement un ou plusieurs candidats de la gestion.

Étapes :  

* Dans la liste des candidats, sélectionnez le ou les candidats à supprimer en cochant les cases correspondantes
* Cliquez sur l’icône 🗑️ (corbeille) située en haut à gauche de la liste
* Une fenêtre de confirmation s’affiche pour valider l’action  

![Candidats](./images/confirmation_supp_candidats.png)

* Cliquez sur **CONFIRMER** pour valider la suppression ou sur **ANNULER** pour interrompre l’opération
* Les candidats supprimés disparaissent immédiatement de la liste

Remarques :  

* La suppression est définitive et ne peut pas être annulée
* Les candidats supprimés n’auront plus accès à la gestion ni à leurs données
* Il est possible de supprimer un ou plusieurs candidats en une seule action grâce à la sélection multiple
* Les informations concernant les résultats du candidat (notes, historiques d’épreuves, statistiques) ne sont pas supprimées et restent accessibles dans la gestion

## Initialisation du compte candidat

La fonction Initialisation du compte candidat permet d’envoyer un e-mail d’invitation à un ou plusieurs candidats afin qu’ils puissent installer l’application PROOVme et définir leur mot de passe d’accès.

Étapes :  

* Dans la liste des candidats, sélectionnez le ou les candidats concernés en cochant les cases correspondantes.
* Cliquez sur l’icône ✉️ (enveloppe) située en haut à gauche de la liste.

![Candidats](./images/com_candidats.png)

* Un e-mail est automatiquement envoyé à chaque candidat sélectionné
* Cet e-mail contient :  

    * Le code de l’établissement
    * L’identifiant du candidat
    * Un mot de passe temporaire
    * Les instructions pour télécharger et installer l’application PROOVme (Windows ou Mac OS)
    * Les consignes de sécurité et les étapes pour initialiser le mot de passe définitif

### Exemple d’e-mail reçu par le candidat :  

![Candidats](./images/init_mail_candidats.png)

* Un lien direct vers le store Microsoft ou Apple pour télécharger PROOVme
* Ses informations de connexion (code établissement, identifiant, mot de passe temporaire)
* La procédure pour définir son mot de passe définitif lors de la première connexion

Remarques :  

* Tant que le candidat n’a pas initialisé son mot de passe, l’icône affichée dans la colonne Mot de passe reste en état cadenas bleu avec montre
* Une fois le mot de passe défini, l’état passe en cadenas vert
* Il est possible d’envoyer l’e-mail à un ou plusieurs candidats en une seule action
* Pour des raisons de sécurité, il est conseillé de demander aux candidats de changer régulièrement leur mot de passe


## Importer des candidats

La fonction **Importer des candidats** permet d’ajouter rapidement plusieurs candidats en une seule opération, grâce à un fichier CSV contenant leurs informations.

Étapes :  

* Dans la rubrique Candidats, cliquez sur l’icône (importer un fichier candidats) située en haut à droite de la liste

![Candidats](./images/imp_candidats.png)

* Sélectionnez le fichier CSV à importer depuis votre poste
* Une fenêtre de configuration s’affiche automatiquement pour définir les propriétés du fichier :

![Candidats](./images/conf_imp_candidats.png)

* Nom du fichier : affiché automatiquement.
* Avec en-tête : cochez cette option si la première ligne du fichier contient les noms de colonnes

![Candidats](./images/conf_tab_imp_candidats.png)

* Séparateur : choisissez le séparateur utilisé dans le fichier.  

    Les options disponibles sont :  

    * Tabulation
    * Point-virgule
    * Virgule
    * Espace

⚠️ Il est important de sélectionner le bon séparateur, correspondant à la structure réelle de votre fichier CSV, pour que les colonnes soient correctement reconnues.  
   
* Cliquez sur **AFFICHER** pour prévisualiser le contenu du fichier
* Dans l’écran de prévisualisation :  

![Candidats](./images/dash_imp_candidats.png)

* Vérifiez la correspondance des colonnes (Identifiant, Nom, Prénom, Date de naissance, E-mail, Téléphone)
* Associez si nécessaire une Promotion, des Tags ou une Liste de candidats
* Contrôlez les statuts en bas d’écran :  

    * ✅ Corrects : candidats prêts à être importés
    * ❌ Incorrects : données invalides ou manquantes
    * ⚠️ Incohérents : doublons ou informations contradictoires
    * 🔁 Doublons : candidats déjà existants sur la gestion

* Importation :
    * Vous pouvez importer au fur et à mesure, en cliquant sur le bouton **IMPORTER** affiché en bout de ligne pour chaque candidat correct
    * Ou bien importer tous les candidats valides en une seule fois, en cliquant sur le bouton **IMPORTER TOUS LES CANDIDATS CORRECTS**

* Les candidats importés apparaissent immédiatement dans la liste des candidats.

Remarques :  

* Les champs Identifiant, Nom, Prénom et E-mail sont obligatoires dans le fichier CSV
* Les candidats incorrects ou incohérents doivent être corrigés avant de pouvoir être importés
* Vous pouvez relancer l’import avec un fichier mis à jour à tout moment
* Après l’importation, il est nécessaire d’envoyer un e-mail d’initialisation (via le bouton ✉️ enveloppe) pour permettre aux candidats d’activer leur compte et de définir leur mot de passe