# Gestion des sujets

La rubrique Gestion des sujets permet de visualiser, organiser et administrer l’ensemble des sujets créés sur la gestion.
Elle constitue l’espace central de suivi des contenus d’évaluation mis à disposition des responsables et des gestionnaires.

![Sujets](./images/gestion.png)

Le tableau récapitulatif affiche pour chaque sujet les informations principales :

* Intitulé : titre du sujet (ex. : L’Europe des Lumières : idées et transformations au XVIIIᵉ siècle)
* Type : définit le mode de partage du sujet
    * Global : le sujet est accessible à d’autres utilisateurs
    * Privé : le sujet est visible uniquement par son créateur
* Type de question : format du sujet (QCM, QCU, Rédaction, etc.)
* Nombre de questions : total de questions incluses
* Durée prévue : durée indicative pour le sujet
* Catégories : matière ou niveau auquel le sujet est rattaché

## État des sujets
Les sujets peuvent se trouver dans différents états :

* En cours de réalisation ou terminés mais non validés : ces sujets restent modifiables par leur auteur
* Validés : ces sujets sont identifiés par un pictogramme vert avec une coche blanche. Ils sont considérés comme finalisés et peuvent être utilisés pour une épreuve
* Un sujet validé n’est plus modifiable ni supprimable
* Pour le modifier ou le supprimer, il faut d’abord le dévalider, ce qui le rend à nouveau éditable

## Interaction avec les épreuves
* Lorsqu’un sujet validé est assigné à une épreuve programmée, sa suppression n’impacte pas l’épreuve : le sujet est déjà intégré dans le package de l’épreuve
* En revanche, si l’épreuve est déprogrammée, le système informera l’utilisateur que le sujet n’existe plus sur la gestion

Dans ce cas, il sera impossible de reprogrammer l’épreuve tant qu’un nouveau sujet n’aura pas été assigné.

## Actions disponibles

* **Ajouter un sujet :** ouvre la fenêtre de création d’un nouveau sujet
* **Modifier un sujet (icône crayon) :** permet d’éditer le contenu ou les paramètres d’un sujet non validé
* **Supprimer un sujet (icône corbeille) :** retire définitivement le sujet de la base (uniquement si non validé)
* **Rechercher :** la barre de recherche située en haut de page permet de filtrer rapidement les sujets par mots-clés

Cette interface offre une vue d’ensemble claire pour faciliter la création, la mise à jour et la gestion quotidienne des sujets d’évaluation.

