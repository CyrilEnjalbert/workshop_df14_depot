# Création d’un sujet dans PROOVme

## Objectif

Cette rubrique permet à un utilisateur (responsable) de concevoir un nouveau sujet d’épreuve dans PROOVme.

Chaque sujet comprend :

* Un descriptif (informations générales),
* Un questionnaire (ensemble de questions),
* Un système de notation,
* Et des options de configuration.

## Accès à la création d’un sujet

**Étape 1** : Ouvrir la fenêtre de création

Depuis la liste des sujets, cliquez sur le bouton **« + AJOUTER UN SUJET »**.
Une fenêtre s’affiche (voir capture ci-dessous) :
![Sujets](./images/create subject.png)

* Saisir l’intitulé du sujet,
* Choisir le type :

    * Sujet global (partageable avec d’autres utilisateurs du même établissement)
    * Sujet privé (visible uniquement par son créateur)

Continuer par **"CRÉER"**.

## Rubrique Descriptif ##

Une fois le sujet créé, la page s’ouvre sur l’onglet Descriptif.
![Sujets](./images/info subject.png)

Exemple : **Sujet – “L’intelligence artificielle et la transformation du marché du travail”**


Champs à compléter :

**Intitulé du sujet**
    Titre général de l’épreuve. (Ex : L’intelligence artificielle et la transformation du marché du travail)



**Description**
    Présente les objectifs et le contenu du sujet. (Ex : Étude des effets de l’IA sur l’emploi, la productivité et les compétences. L’épreuve interroge la manière dont les économies peuvent accompagner cette mutation technologique sans creuser les inégalités.)


**Durée de l’épreuve prévue**
Temps imparti à l’épreuve (ex. : 1h)
Ce champ permet d’indiquer le temps estimé nécessaire pour la réalisation complète du sujet.

⚠️ Il s’agit d’une durée indicative : elle n’impose pas de limite réelle à la passation.

Cette information est utilisée principalement pour :

* Donner une idée du volume de travail attendu
* Aider à la planification lors de la création d’une épreuve
* Faciliter le paramétrage ultérieur de la durée réelle dans le module Épreuve

💡 Exemple :

Si le sujet « L’intelligence artificielle et la transformation du marché du travail » est estimé à 1h, cela signifie qu’il correspond à une épreuve d’environ une heure, mais la durée réelle pourra être ajustée par le responsable au moment de la programmation de l'épreuve.


**Catégories**
Permet d’associer le sujet à une ou plusieurs thématiques (matière, niveau, spécialité, etc.).
![Sujets](./images/Choix des categories.png)


**Sélection des catégories** :

Cliquez sur Catégories, puis cochez les éléments correspondants :

* Matière : Histoire-Géographie, Mathématiques, Économie…
* Spécialité : Français/Anglais, Sciences, etc.
* Sous-thèmes : Développement durable, Mondialisation, IA et économie…
* Niveau de difficulté : Débutant, Intermédiaire, Avancé.

Exemple de combinaison :
Sciences économiques et sociales – Mondialisation – Intelligence artificielle et économie – Intermédiaire.
![Sujets](./images/Select category.png)

💡 **Important** :
Les catégories disponibles sont définies et gérées par l’administrateur de la gestion PROOVme.
Les créateurs de sujets ne peuvent pas en ajouter de nouvelles, mais uniquement sélectionner celles qui leur sont proposées dans la liste.

## Rubrique Questionnaire ##

L’onglet Questionnaire permet de créer les différentes parties et questions du sujet.

**Étape 1 : Créer une partie**

Lors de la création d’un nouveau sujet, une première partie est automatiquement créée par défaut.
Il suffit simplement de lui attribuer un intitulé (ex. : Partie 1 – Compréhension du thème).

* Chaque sujet doit contenir au minimum une partie
* Les questions sont obligatoirement rattachées à une partie

Il n’est donc pas possible d’ajouter une question sans qu’elle appartienne à une partie existante.

Les parties permettent :

* d’organiser le sujet en sections cohérentes,
* de regrouper plusieurs questions autour d’un même thème ou d’un même type d’exercice,
* et de faciliter la lecture et la navigation dans l’interface du module de passation.

![Sujets](./images/create subject.png)

💡 **Conseil** :
Vous pouvez créer autant de parties que nécessaire pour structurer le sujet (ex. : Partie 1 – Compréhension, Partie 2 – Analyse, Partie 3 – Rédaction ouverte).

**Étape 2 : Ajouter une question**

Cliquez sur **+ QUESTION**, puis choisissez le type de question parmi les options proposées.

![Sujets](./images/liste de type question.png)

**Types de questions fermées** :

* Question à réponse multiple (QCM) : Plusieurs réponses possibles
* Question à réponse unique : Une seule réponse correcte
* Vrai / Faux : Affirmation à valider ou invalider
* Correspondance : Faire correspondre des éléments entre deux colonnes
* Séquence : Remettre des étapes ou éléments dans l’ordre
* Réponse courte : L’utilisateur saisit un texte ou une valeur courte

**Types de questions ouvertes** :

* Rédaction longue : Permet une réponse développée, type dissertation, analyse ou synthèse

**Étape 3 : Rédiger la question**

Saisissez votre texte dans la zone prévue.

Vous pouvez :

* insérer une image ou un document annexe,
* utiliser les outils de mise en forme (gras, italique, liste, symbole mathématique, etc.),
* prévisualiser la question en vue partagée ou vue séparée.

**Étape 4 : Ajouter les propositions**

Pour les questions fermées, cliquez sur + Ajouter une proposition, puis indiquez les réponses possibles.
Sélectionnez la ou les bonnes réponses selon le type de question.

5. Rubrique Système de notation

Cette section permet de définir comment le sujet sera noté.

Notation automatique
Pour les QCM ou questions fermées : la note est calculée automatiquement selon les bonnes réponses.

Notation manuelle
Pour les questions ouvertes : la correction est faite par le correcteur.

Barème global
Permet de fixer la note totale du sujet (ex. : sur 20 ou sur 100).

Pondération
Vous pouvez ajuster le poids de chaque question ou partie.

6. Rubrique Options

La rubrique Options permet de configurer des paramètres complémentaires :


Accès à l’épreuve
Mode libre ou déclenchement par le responsable.

Visibilité
Sujet partagé (global) ou réservé (privé).

Annexes
Possibilité d’ajouter des documents de référence pour le candidat.

Rendu final
Permet de prévisualiser le sujet complet avant validation.

7. Validation du sujet

Lorsque toutes les rubriques sont complétées :
	1.	Cliquez sur RENDU FINAL pour visualiser le résultat complet.
	2.	Puis sur VALIDER pour enregistrer définitivement le sujet.

Une fois validé, le sujet peut être utilisé pour créer une épreuve.
Pour le modifier, il faut d’abord le dévalider.

