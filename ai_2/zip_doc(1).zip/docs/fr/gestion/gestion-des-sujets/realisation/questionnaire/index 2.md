## Rubrique Questionnaire ##

L’onglet Questionnaire permet de créer les différentes parties et questions du sujet.

**Étape 1 : Créer une partie**

Lors de la création d’un nouveau sujet, une première partie est automatiquement créée par défaut.
Il suffit simplement de lui attribuer un intitulé (ex. : Partie 1 – Compréhension du thème).

* Chaque sujet doit contenir au minimum une partie
* Les questions sont obligatoirement rattachées à une partie

Il n’est donc pas possible d’ajouter une question sans qu’elle appartienne à une partie existante.

Les parties permettent :

* d’organiser le sujet en sections cohérentes,
* de regrouper plusieurs questions autour d’un même thème ou d’un même type d’exercice,
* et de faciliter la lecture et la navigation dans l’interface du module de passation.

![Sujets](./images/create subject.png)

💡 **Conseil** :
Vous pouvez créer autant de parties que nécessaire pour structurer le sujet (ex. : Partie 1 – Compréhension, Partie 2 – Analyse, Partie 3 – Rédaction ouverte).

**Étape 2 : Ajouter une question**

Cliquez sur **+ QUESTION**, puis choisissez le type de question parmi les options proposées.

![Sujets](./images/liste de type question.png)

**Types de questions fermées** :

* Question à réponse multiple (QCM) : Plusieurs réponses possibles
* Question à réponse unique : Une seule réponse correcte
* Vrai / Faux : Affirmation à valider ou invalider
* Correspondance : Faire correspondre des éléments entre deux colonnes
* Séquence : Remettre des étapes ou éléments dans l’ordre
* Réponse courte : L’utilisateur saisit un texte ou une valeur courte

**Types de questions ouvertes** :

* Rédaction longue : Permet une réponse développée, type dissertation, analyse ou synthèse

**Étape 3 : Rédiger la question**

Rédigez votre question.

Vous pouvez :

* Vous pouvez ajouter une annexe à votre question. Lors de cette action, une fenêtre s’ouvre et vous permet de sélectionner un fichier PDF ou une vidéo, de la même façon que pour l’ajout d’un média.
![Sujets](./images/add annexe.png)

![Sujets](./images/select annexe.png)

* utiliser les outils de mise en forme (gras, italique, liste, symbole mathématique, etc.),
![Sujets](./images/toolbar intitule.png)

* Modifier le barème uniquement pour la question à l'aide du bouton engrenage
![Sujets](./images/modif bareme question.png)

* Une fois votre question complétée, vous avez la possibilité de la prévisualiser grâce au pictogramme en forme d’œil 👁️, afin de voir exactement comment le candidat la verra lors de la passation.
![Sujets](./images/prevue question.png)
