# Rubrique Descriptif #

Une fois le sujet créé, la page s’ouvre sur l’onglet Descriptif.

![Sujets](./images/info_subject.png)

Le champs à compléter correspond à **l'intitulé du sujet** (Ex : L’intelligence artificielle et la transformation du marché du travail)

![Sujets](./images/descriptif_subject.png)
Le champ **Description** permet d’indiquer les objectifs et le contenu du sujet.
(Exemple : Étude des effets de l’intelligence artificielle sur l’emploi, la productivité et les compétences. L’épreuve interroge la manière dont les économies peuvent accompagner cette mutation technologique sans creuser les inégalités.)

**Durée de l’épreuve prévue**
Temps imparti à l’épreuve (ex. : 1h)
Ce champ permet d’indiquer le temps estimé nécessaire pour la réalisation complète du sujet.

⚠️ Il s’agit d’une durée indicative : elle n’impose pas de limite réelle à la passation.

Cette information est utilisée principalement pour :

* Donner une idée du volume de travail attendu
* Aider à la planification lors de la création d’une épreuve
* Faciliter le paramétrage ultérieur de la durée réelle dans le module Épreuve

💡 Exemple :

Si le sujet « L’intelligence artificielle et la transformation du marché du travail » est estimé à 1h, cela signifie qu’il correspond à une épreuve d’environ une heure, mais la durée réelle pourra être ajustée par le responsable au moment de la programmation de l'épreuve.


**Catégories**
Permet d’associer le sujet à une ou plusieurs thématiques (matière, niveau, spécialité, etc.).
![Sujets](./images/choix_des_categories.png)


**Sélection des catégories** :

Cliquez sur Catégories, puis cochez les éléments correspondants :

* Matière : Histoire-Géographie, Mathématiques, Économie…
* Spécialité : Français/Anglais, Sciences, etc.
* Sous-thèmes : Développement durable, Mondialisation, IA et économie…
* Niveau de difficulté : Débutant, Intermédiaire, Avancé.

Exemple de combinaison :
Sciences économiques et sociales – Mondialisation – Intelligence artificielle et économie – Intermédiaire.
![Sujets](./images/Select_category.png)

💡 **Important** :
Les catégories disponibles sont définies et gérées par l’administrateur de la gestion PROOVme.
Les créateurs de sujets ne peuvent pas en ajouter de nouvelles, mais uniquement sélectionner celles qui leur sont proposées dans la liste.

