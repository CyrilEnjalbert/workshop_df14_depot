# Création d’un sujet dans PROOVme

Cette rubrique permet à un utilisateur (responsable) de concevoir un nouveau sujet d’épreuve dans PROOVme.

## Accès à la création d’un sujet

Depuis la liste des sujets, cliquez sur le bouton **« + AJOUTER UN SUJET »**.

Une fenêtre s’affiche (voir capture ci-dessous) :

![Sujets](./images/subject_create.png)

Saisir l’intitulé du sujet,

Choisir le type :

* **Sujet global**
Le sujet est partageable avec d’autres utilisateurs du même établissement, mais non modifiable ni supprimable par ces utilisateurs.
Seul le créateur peut en effectuer la modification ou la suppression.

* **Sujet privé**
Le sujet est visible uniquement par son créateur, librement modifiable et supprimable par celui-ci.

Pour poursuivre la création, cliquez sur le bouton **"CRÉER"**.

Chaque sujet comprend :

* [Descritif :](descriptif/) Un descriptif (informations générales),
* [Questionnaire :](questionnaire/) Un questionnaire (ensemble de questions),
* [Systèmes de notation :](system-notation/) Un système de notation,
* [Options :](options/) Et des options de configuration.

