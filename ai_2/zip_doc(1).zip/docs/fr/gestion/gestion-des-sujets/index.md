# Sujet
La rubrique Sujets permet de créer, organiser et gérer l’ensemble des sujets d’évaluation utilisés sur la gestion.
Elle centralise la conception des sujets, leur contenu, leurs paramètres et leur mise à disposition pour les épreuves.

Depuis cet espace, les utilisateurs habilités peuvent : 

* Créer un nouveau sujet à partir d’une page vierge

* Modifier un sujet existant (titre, description, questions, annexes, etc...)

Cette rubrique constitue ainsi le point central de la préparation des épreuves, garantissant la cohérence et la traçabilité des contenus d’évaluation.

### Sous rubriques de la rubrique **Sujet**

* [Réalisation d'un sujet :](realisation/) Réalisation d'un sujet sur la Plateforme PROOVme

* [Gestion d'un sujet :](gestion/) Gestion des sujets sur la Plateforme PROOVme

