La sous-rubrique **Rôles** permet d’attribuer des droits et des responsabilités spécifiques aux utilisateurs de la gestion. Trois rôles distincts existent, chacun répondant à un niveau d’accès et de mission particulier :

Le tableau affiche la liste des utilisateurs associés à chaque rôle (Administrateur, Gestionnaire ou Responsable).  

Il présente pour chaque membre les informations suivantes :  

* Nom et Prénom
* Adresse e-mail
* Identifiant de connexion

Une pastille colorée permet d’indiquer l’état de connexion de l’utilisateur (connecté, déconnecté).
Chaque ligne inclut également une icône d’action permettant de retirer un membre du rôle.

Ce tableau offre ainsi une vue claire des utilisateurs affectés à un rôle et permet d’en gérer facilement la composition.

## Description des rôles

 **1. Administrateur** 

![roles](./images/admin_role_users.png)

* Dispose des droits les plus étendus
* Accède à l’ensemble des fonctionnalités d’administration des utilisateurs et des candidats
* Peut gérer les paramètres généraux de l’application (sessions, catégories, etc.) et définir les éléments utilisés par les responsables
* Gère la configuration globale de l’établissement 


 **2. Gestionnaire** 

![roles](./images/gest_role_users.png)

* Intervient sur les épreuves organisées globalement par l’établissement (hors épreuves privées organisées par les responsables)
* Assiste les responsables dans l’organisation des épreuves, notamment sur les aspects logistiques et de passation
* Joue un rôle de support opérationnel auprès des responsables

 **3. Responsable** 

![roles](./images/resp_role_users.png)

* Crée les épreuves et les sujets
* Gère tous les aspects liés à ses évaluations : passation, correction et ajustement des résultats
* Peut organiser ses évaluations en autonomie (évaluations privées) ou en collaboration avec les gestionnaires pour des épreuves organisées globalement sur l’établissement

## Actions disponibles

### Ajouter un membre

La fonction Ajouter un membre permet d’affecter un utilisateur existant à un rôle spécifique (Administrateur, Gestionnaire ou Responsable).

![roles](./images/add_membre_role_users.png)

**Étapes d’utilisation** 

* Cliquez sur **+ AJOUTER UN MEMBRE** depuis la liste des rôles
* Une fenêtre de sélection s’ouvre, affichant la liste complète des utilisateurs disponibles
* Utilisez la barre de recherche ou les filtres pour faciliter la sélection (par nom, prénom, e-mail ou identifiant)
* Cochez un ou plusieurs utilisateurs que vous souhaitez associer au rôle
* Cliquez sur **Ajouter** pour valider l’affectation

**Actions disponibles** 

* **Ajouter** : confirme l’attribution du rôle aux utilisateurs sélectionnés
* **Annuler** : ferme la fenêtre sans enregistrer de modification

👉 Une fois ajoutés, les utilisateurs apparaissent directement dans la liste du rôle concerné et bénéficient immédiatement des droits associés.


### Supprimer un membre

La fonction Supprimer un membre d’un rôle permet de retirer un utilisateur d’un rôle attribué (Administrateur, Gestionnaire ou Responsable), sans supprimer son compte de la gestion.  
Cette action est représentée par l’icône  ![roles](./images/select_supp_membre_role_users.png)

située en face du nom de l’utilisateur dans la liste des membres du rôle.

**Étapes d’utilisation**

* Sélectionnez l’utilisateur à retirer du rôle
* Cliquez sur l’icône Supprimer
* Une fenêtre de confirmation s’affiche pour éviter toute suppression accidentelle

![roles](./images/conf_supp_membre_role_users.png)

**Actions disponibles**

* **Confirmer** : valide l’opération et retire l’utilisateur du rôle sélectionné. Il perd immédiatement les droits associés à ce rôle
* **Annuler** : ferme la fenêtre de confirmation sans effectuer de modification

⚠️ Remarque : la suppression d’un membre d’un rôle ne supprime pas son compte utilisateur. Il reste présent dans la liste générale des utilisateurs et peut être affecté à un autre rôle ultérieurement.
