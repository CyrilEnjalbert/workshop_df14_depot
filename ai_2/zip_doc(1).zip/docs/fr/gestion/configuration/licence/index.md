# Licence
Cette rubrique vous permet de vérifier si votre licence est **valide**.  

![licence](images/licence.png)

Elle indique la période pendant laquelle vous pouvez utiliser la solution.

Vous y trouverez également des informations sur les éléments suivants :  

* Le nombre de candidats dans l’établissement
* Le nombre d’épreuves
* Le nombre de candidats par épreuve
* Le nombre de compositions réalisées

Pour chacun de ces éléments, le seuil limite est précisé. Si celui-ci est dépassé, la licence n’est plus considérée comme valide.